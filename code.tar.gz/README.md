感谢233boy

自己用，基于233boy安装脚本魔改

安装及使用：https://233boy.com/sing-box/sing-box-script/